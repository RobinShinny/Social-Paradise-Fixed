<?php
header("Location: UpgradeAccount.php");
?>