<?php
header("Location: MyWall.php");
?>