</div>
</main>
</div>
<br />

<style>
.Container {
  flex: 1;
  /* Set a minimum height equivalent to 100% of the viewport height minus the height of the footer */
  min-height: calc(100vh - 70px);
}

/* Footer styles */
.footer {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 70px;
  background: #e6e6e6;
  color: #aaa;
}
</style>

<footer class="footer">
  <div class="footer-content">
	<b>
	Copyright &copy; 2023 Social-Paradise - <a href='../siterules.php'>Terms Of Service</a> - <a href='../Contact.php'>Contact Us</a>
	</b>
  </div>
</footer>
<br />