<?php
include_once "Header.php";
echo '<script>window.location.href = "/Memberships/UpgradeAccount.php";</script>';
?>