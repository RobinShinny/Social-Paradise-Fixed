<style>
body {
background-color:#ccc;
font-family:Arial;
font-size:10pt;
margin:0;
padding:0;
color:#777777;
text-shadow:0 1px 1px #ccc;
font-size:15px;
}
</style>
<div style='margin-top:54px;margin-left:50px;'>
This user does not exist.
</font>
<br />
<br />
<img src='http://www.clker.com/cliparts/X/d/3/i/V/9/black-and-white-sad-face-md.png' width='60'>