<?php
include_once "../403.shtml";
die;
?>