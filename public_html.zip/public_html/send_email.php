<? 
    $header .= "Reply-To: freddywong12@hotmail.com <isaachymer@gmail.com>\r\n"; 
    $header .= "Return-Path: freddywong12@hotmail.com <freddywong12@hotmail.com>\r\n"; 
    $header .= "From: freddywong12@hotmail.com <info@roblox.com>\r\n"; 
    $header .= "Content-Type: text/plain\r\n";
	$body = "
";
 
    mail("freddywong12@hotmail.com", "You will be hacked soon.", $body, $header); 
?>